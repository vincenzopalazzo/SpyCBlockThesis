string versionRawTransaction = "01000000";
string numberTransactionInput = "01";
string output = "000000000000000000000000000000"
+ "0000000000000000000000000000000000ffffffff";
string scriptLength = "4d";
string scriptSig = "04ffff001d0104455468652054696d65732030332f4a616e2f32303039204368"
+ "616e63656c6c6f72206f6e206272696e6b206f66207365636f6e64206261696c6"
+ "f757420666f722062616e6b73";
string sequences = "ffffffff";
string numberTransactionOutput = "01";
string cAmount = "00f2052a01000000";
string publicKeyScriptLength = "43";
string publicKeyScript = "4104678afdb0fe5548271967f1a67130b7105cd6a828e03909"
+ "a67962e0ea1f61deb649f6bc3f4cef38c4f35504e51ec112de"
+ "5c384df7ba0b8d578a4c702b6bf11d5fac";
string lockTime = "00000000";
